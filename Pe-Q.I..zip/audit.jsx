/* Pe-Q.I — Audit tab */

const { useState: useStateA } = React;

function Audit({ scenario }) {
  const [open, setOpen] = useStateA(0);

  return (
    <div className="tab-panel">
      <header style={{ marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div>
          <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, letterSpacing: "0.16em", color: "var(--ink-500)", textTransform: "uppercase" }}>
            Audit trail · {scenario.requestId}
          </div>
          <h2 style={{ fontFamily: "var(--f-display)", fontStyle: "italic", fontWeight: 400, fontSize: 32, margin: "6px 0 0", letterSpacing: "-0.01em" }}>
            Every step the system took, on the record.
          </h2>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button className="btn btn--ghost">copy payload</button>
          <button className="btn btn--override">download .jsonl</button>
        </div>
      </header>

      <div className="audit-grid">
        {/* ── Tool calls ───────────────────────────────────── */}
        <div className="card">
          <div className="card__head">
            <h3>Tool gateway · executed</h3>
            <span className="meta">{scenario.tools.length} calls · {scenario.tools.filter(t => t.status === "success").length} success</span>
          </div>
          <p className="card__subtle">
            Gemma proposes the next tool; the ToolGateway validates and executes under whitelist, schema, state order, and local ID validation.
            Click any call to inspect its arguments and result.
          </p>
          {scenario.tools.map((t, i) => (
            <div className="tool-call" key={t.name}>
              <div className="tool-call__head" onClick={() => setOpen(open === i ? -1 : i)}>
                <span className="tool-call__idx">{String(i + 1).padStart(2, "0")}</span>
                <span className="tool-call__name">{t.name}</span>
                <span className="tool-call__status" data-s={t.status}>{t.status}</span>
                <span className="tool-call__latency">{t.latency} ms</span>
              </div>
              {open === i && (
                <div className="tool-call__body">
                  <div className="lbl">arguments</div>
                  <pre>{JSON.stringify(t.args, null, 2)}</pre>
                  <div className="lbl">result</div>
                  <pre>{JSON.stringify(t.result, null, 2)}</pre>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* ── Right column: state machine, hashes, planner ── */}
        <div className="ctx">
          {/* State machine */}
          <div className="card">
            <div className="card__head">
              <h3>State machine</h3>
              <span className="meta">canonical flow</span>
            </div>
            <p className="card__subtle">Every transition is timestamped. Errors surface as BLOCKED, REVIEW_REQUIRED, or ERROR_TERMINAL — never silent fallback.</p>
            <div className="state-machine">
              {scenario.stateMachine.map(s => (
                <div className="state-machine__node" key={s.state} data-active={String(s.active)}>
                  <span className="state-machine__bullet">
                    {s.active === "current" ? "●" : s.active === true ? "✓" : ""}
                  </span>
                  <span className="state-machine__name">{s.state}</span>
                  <span className="state-machine__time">{s.t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Source hashes */}
          <div className="card">
            <div className="card__head">
              <h3>Source hashes</h3>
              <span className="meta">sha-256 · 5 inputs</span>
            </div>
            <p className="card__subtle">Every input is hashed. The decision can be reconstructed from the payload alone.</p>
            <div>
              {Object.entries(scenario.sourceHashes).map(([k, v]) => (
                <div className="hash-row" key={k}>
                  <span className="hash-row__k">{k}</span>
                  <span className="hash-row__v">{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Planner intent log */}
          <div className="card">
            <div className="card__head">
              <h3>Planner intent log</h3>
              <span className="meta">5 steps · 0 retries</span>
            </div>
            <p className="card__subtle">What Gemma intended at each step, and which tool the gateway permitted.</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {scenario.planner.map(p => (
                <div key={p.step} style={{
                  display: "grid",
                  gridTemplateColumns: "24px 1fr auto",
                  gap: 10,
                  padding: "9px 0",
                  borderTop: "1px solid var(--hair)",
                  fontFamily: "var(--f-mono)",
                  fontSize: 11.5,
                  alignItems: "center",
                }}>
                  <span style={{ color: "var(--ink-400)", fontSize: 10 }}>{String(p.step).padStart(2, "0")}</span>
                  <span>
                    <span style={{ color: "var(--ink-900)" }}>{p.intent}</span>
                    <br />
                    <span style={{ color: "var(--ink-500)", fontSize: 10.5 }}>via {p.tool}</span>
                  </span>
                  <span style={{ color: "var(--forest-700)", fontSize: 10 }}>→ {p.state}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Audit });
