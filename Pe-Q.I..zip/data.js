/* ─────────────────────────────────────────────────────────────────
   Pe-Q.I — Scenario data
   Grounded in scenarios/cases/S10_FIFO_BREAK_JUSTIFIED + sister cases
   ───────────────────────────────────────────────────────────────── */

window.DESTINATIONS = [
  { id: "DST-OPEN-01",   type: "open_hopper",     exposure: "open",    vehicles: ["truck", "bitrem", "rodotrem"], loads: ["dry"] },
  { id: "DST-COV-01",    type: "covered_hopper",  exposure: "covered", vehicles: ["truck"], loads: ["dry"] },
  { id: "DST-WET-01",    type: "wet_load_hopper", exposure: "covered", vehicles: ["truck", "bitrem"], loads: ["wet", "dry"] },
  { id: "DST-NARROW-01", type: "narrow_hopper",   exposure: "covered", vehicles: ["truck"], loads: ["dry"] },
];

window.HARD_CONSTRAINTS = {
  "HC-01": "Open destination blocked by rain",
  "HC-02": "Wet load requires compatible destination",
  "HC-03": "Down or blocked resource cannot receive",
  "HC-04": "Document block prevents dispatch",
  "HC-05": "Vehicle type not allowed for destination",
  "HC-06": "Below minimum operational capacity",
  "HC-07": "Override cannot bypass hard constraints",
};

window.RANKING_RULES = {
  "PR-01": { name: "FIFO position",        weight: 40 },
  "PR-02": { name: "Contract priority",    weight: 30 },
  "PR-03": { name: "Capacity headroom",    weight: 10 },
  "PR-04": { name: "Wait SLA pressure",    weight: 5  },
  "PR-05": { name: "No valid pair",        weight: 0  },
  "PR-06": { name: "Resource fit",         weight: 15 },
};

/* ── Primary case: S10 — FIFO break justified ────────────────── */
window.SCENARIO_S10 = {
  id: "S10_FIFO_BREAK_JUSTIFIED",
  short: "S10",
  name: "fifo break justified",
  summary: "Rain blocks open hoppers; the covered hopper accepts only the truck waiting in #5. Pure FIFO would call an ineligible bitrem.",
  state: "preview",
  requestId: "REQ-2026-0010",
  operator: "OP-DEMO-01",
  recommendedTruck: "TRK-005",
  recommendedDestination: "DST-COV-01",
  decisionStatus: "PREVIEW_READY",
  reasonSummary: "FIFO break justified by vehicle compatibility under rain — the open lane is blocked by HC-01 and bitrems cannot enter the covered lane (HC-05).",
  firedRules: ["PR-01", "PR-04"],
  hardConstraints: ["HC-01", "HC-05"],
  rejected: 9,
  latencyMs: 1,
  weather: { precipitation: "rain", severity: "high", at: "2026-04-04 10:45 UTC" },
  ticket: {
    id: "TCK-S10-005",
    truckId: "TRK-005",
    vehicleType: "truck",
    documentStatus: "clear",
    documentBlockFlags: [],
    loadCondition: "dry",
    contractPriority: false,
    parseConfidence: 0.94,
    fields: ["ticket_id", "truck_id", "vehicle_type", "document_status", "load_condition"],
  },
  operatorNote: "Chuva bloqueou destino aberto; coberta aceita apenas truck neste momento.",
  operatorNoteEn: "Rain blocked open destinations; covered hopper only accepts truck at this moment.",
  driverMessage: "Call TRK-005 to DST-COV-01. FIFO break justified by long wait time and rain conditions on open hoppers. Approach covered hopper bay 01.",
  queue: [
    { pos: 1, id: "TRK-001", vehicle: "bitrem",   destDeclared: "DST-OPEN-01", contract: false, blocked: ["HC-01"],         status: "blocked", arrivalIso: "2026-04-04T08:00:00+00:00", waitMin: 165 },
    { pos: 2, id: "TRK-002", vehicle: "bitrem",   destDeclared: "DST-COV-01",  contract: false, blocked: ["HC-05"],         status: "blocked", arrivalIso: "2026-04-04T08:04:00+00:00", waitMin: 161 },
    { pos: 3, id: "TRK-003", vehicle: "bitrem",   destDeclared: "DST-OPEN-01", contract: false, blocked: ["HC-01"],         status: "blocked", arrivalIso: "2026-04-04T08:08:00+00:00", waitMin: 157 },
    { pos: 4, id: "TRK-004", vehicle: "bitrem",   destDeclared: "DST-COV-01",  contract: false, blocked: ["HC-05"],         status: "blocked", arrivalIso: "2026-04-04T08:12:00+00:00", waitMin: 153 },
    { pos: 5, id: "TRK-005", vehicle: "truck",    destDeclared: "DST-COV-01",  contract: false, blocked: [],                status: "called",  arrivalIso: "2026-04-04T08:16:00+00:00", waitMin: 149 },
  ],
  resources: [
    { id: "DST-OPEN-01",   status: "blocked",   capacity: 85, blockedBy: "HC-01", note: "Rain (high)"  },
    { id: "DST-COV-01",    status: "available", capacity: 85, blockedBy: null,    note: "Covered, truck-only" },
    { id: "DST-WET-01",    status: "available", capacity: 72, blockedBy: null,    note: "Wet load only" },
    { id: "DST-NARROW-01", status: "available", capacity: 40, blockedBy: null,    note: "Narrow gauge" },
  ],
  tools: [
    { name: "parse_ticket_document",   status: "success", latency: 412, args: { source: "ticket.txt", runtime: "text" },                                     result: { ticket_id: "TCK-S10-005", truck_id: "TRK-005", vehicle_type: "truck", load_condition: "dry", confidence: 0.94 } },
    { name: "classify_exception",      status: "success", latency: 318, args: { note: "Chuva bloqueou destino aberto…", weather: "rain.high" },              result: { kind: "RAIN_ON_OPEN_DESTINATION", confidence: 0.92, evidence_refs: ["weather.severity=high","note.rain"] } },
    { name: "validate_hard_constraints", status: "success", latency: 6, args: { trucks: 5, destinations: 4 },                                                  result: { rejected_pairs: 9, fired: ["HC-01","HC-05"], eligible_pairs: 11 } },
    { name: "rank_candidates",         status: "success", latency: 4, args: { profile: "v1-demo", eligible: 11 },                                              result: { top: { truck: "TRK-005", destination: "DST-COV-01", score: 92.4 }, fired_rules: ["PR-01","PR-04"] } },
    { name: "generate_audit_payload",  status: "success", latency: 3, args: { request_id: "REQ-2026-0010" },                                                   result: { audit_completeness: 1.0, payload_bytes: 3784, source_hashes: 5 } },
  ],
  planner: [
    { step: 1, intent: "Interpret ticket document", tool: "parse_ticket_document", purpose: "Extract structured ticket fields", state: "PARSED" },
    { step: 2, intent: "Resolve operational truth", tool: "classify_exception",    purpose: "Reconcile note × weather × document", state: "INTERPRETED" },
    { step: 3, intent: "Filter eligible pairs",     tool: "validate_hard_constraints", purpose: "Apply HC-01…HC-07 over all pairs", state: "VALIDATED" },
    { step: 4, intent: "Score remaining pairs",     tool: "rank_candidates",       purpose: "Weighted scoring under policy profile v1-demo", state: "RANKED" },
    { step: 5, intent: "Emit auditable payload",    tool: "generate_audit_payload", purpose: "Preview + driver message + provenance", state: "PREVIEW_READY" },
  ],
  sourceHashes: {
    queue_csv_ref:  "sha256:7a1f…be4c",
    ticket_ref:     "sha256:e0c2…1d3a",
    operator_note:  "sha256:91ab…0f72",
    weather_state:  "sha256:4d6e…9c10",
    resource_state: "sha256:b8a3…77fe",
  },
  stateMachine: [
    { state: "RECEIVED",       t: "10:45:18.012", active: true },
    { state: "NORMALIZED",     t: "10:45:18.014", active: true },
    { state: "PARSED",         t: "10:45:18.426", active: true },
    { state: "INTERPRETED",    t: "10:45:18.744", active: true },
    { state: "VALIDATED",      t: "10:45:18.750", active: true },
    { state: "RANKED",         t: "10:45:18.754", active: true },
    { state: "PREVIEW_READY",  t: "10:45:18.757", active: "current" },
    { state: "HUMAN_FINALIZED", t: "pending",     active: false },
  ],
};

/* ── Sister scenarios for the rail ───────────────────────────── */
window.SCENARIOS = [
  { id: "S01_BASELINE",                  short: "S01", name: "baseline operations",                  state: "preview",  category: "Operational baseline" },
  { id: "S02_RAIN_OPEN",                 short: "S02", name: "rain on open destination",            state: "preview",  category: "Operational baseline" },
  { id: "S03_WET_LOAD",                  short: "S03", name: "wet load multimodal",                 state: "preview",  category: "Multimodal robustness" },
  { id: "S04_CONVEYOR_DOWN",             short: "S04", name: "conveyor down",                       state: "review",   category: "Operational baseline" },
  { id: "S05_CONTRACT_PRIORITY",         short: "S05", name: "contract priority",                   state: "preview",  category: "Operational baseline" },
  { id: "S06_DOCUMENT_BLOCK",            short: "S06", name: "document block",                      state: "blocked",  category: "Truth conflicts" },
  { id: "S07_VEHICLE_INCOMPAT",          short: "S07", name: "vehicle incompatibility",             state: "preview",  category: "Operational baseline" },
  { id: "S08_REDUCED_CAPACITY",          short: "S08", name: "reduced capacity",                    state: "preview",  category: "Operational baseline" },
  { id: "S09_HUMAN_OVERRIDE",            short: "S09", name: "human override",                      state: "review",   category: "Governance" },
  { id: "S10_FIFO_BREAK_JUSTIFIED",      short: "S10", name: "fifo break justified",                state: "preview",  category: "Operational baseline" },
  { id: "S11_IMAGE_ROTATED_WET_LOAD",    short: "S11", name: "rotated wet load image",              state: "preview",  category: "Multimodal robustness" },
  { id: "S12_PDF_SCANNED_DOCUMENT_BLOCK",short: "S12", name: "scanned pdf document block",          state: "blocked",  category: "Multimodal robustness" },
  { id: "S13_TRUCK_ID_NOT_IN_QUEUE",     short: "S13", name: "truck id not in queue",               state: "blocked",  category: "Truth conflicts" },
  { id: "S14_NOTE_RAIN_CONFLICT",        short: "S14", name: "note rain vs weather conflict",       state: "review",   category: "Truth conflicts" },
  { id: "S15_UNKNOWN_DESTINATION",       short: "S15", name: "unknown destination in ticket",       state: "blocked",  category: "Truth conflicts" },
  { id: "S16_ALL_DESTINATIONS_BLOCKED",  short: "S16", name: "all destinations blocked",            state: "blocked",  category: "Truth conflicts" },
  { id: "S17_OVERRIDE_INELIGIBLE",       short: "S17", name: "override ineligible pair",            state: "review",   category: "Governance" },
  { id: "S18_OVERRIDE_NON_TOP",          short: "S18", name: "override eligible non-top",           state: "review",   category: "Governance" },
  { id: "S19_TIE_BREAK_EQUAL",           short: "S19", name: "tie-break equal score",               state: "preview",  category: "Governance" },
  { id: "S20_LARGE_QUEUE_100",           short: "S20", name: "large queue · 100 trucks",            state: "preview",  category: "Governance" },
];

/* ── Benchmark data — mirrors README claims ──────────────────── */
window.BENCHMARK = {
  scope: { scenarios: 20, variants: 4, rows: 80 },
  variants: [
    { id: "full",      name: "full",      gemma: true,  match: 1.00, violations: 0.00, exceptionF1: 1.00,  ticketAcc: 0.969, audit: 1.00, toolSuccess: 0.95, plannerSteps: 2.35 },
    { id: "heuristic", name: "heuristic", gemma: false, match: 0.85, violations: 0.00, exceptionF1: 0.678, ticketAcc: 0.85,  audit: 0.85, toolSuccess: null, plannerSteps: null },
    { id: "fifo_safe", name: "fifo_safe", gemma: false, match: 0.75, violations: 0.00, exceptionF1: null,  ticketAcc: null,  audit: 0.75, toolSuccess: null, plannerSteps: null },
    { id: "raw_fifo",  name: "raw_fifo",  gemma: false, match: 0.25, violations: 0.35, exceptionF1: null,  ticketAcc: null,  audit: null,  toolSuccess: null, plannerSteps: null },
  ],
  scenarioEvidence: [
    { id: "S03_WET_LOAD",                  name: "wet load multimodal",        expected: "TRK-007 → DST-WET-01",  full: "match",   heuristic: "blocked", raw: "violate" },
    { id: "S06_DOCUMENT_BLOCK",            name: "document block",             expected: "BLOCKED",               full: "match",   heuristic: "match",   raw: "violate" },
    { id: "S09_HUMAN_OVERRIDE",            name: "human override",             expected: "REVIEW_REQUIRED",       full: "match",   heuristic: "miss",    raw: "violate" },
    { id: "S10_FIFO_BREAK_JUSTIFIED",      name: "fifo break justified",       expected: "TRK-005 → DST-COV-01",  full: "match",   heuristic: "match",   raw: "violate" },
    { id: "S11_IMAGE_ROTATED_WET_LOAD",    name: "rotated wet load image",     expected: "TRK-002 → DST-WET-01",  full: "match",   heuristic: "blocked", raw: "violate" },
    { id: "S12_PDF_SCANNED_DOCUMENT_BLOCK",name: "scanned pdf document block", expected: "BLOCKED",               full: "match",   heuristic: "blocked", raw: "violate" },
    { id: "S16_ALL_DESTINATIONS_BLOCKED",  name: "all destinations blocked",   expected: "BLOCKED",               full: "match",   heuristic: "match",   raw: "violate" },
    { id: "S19_TIE_BREAK_EQUAL",           name: "tie-break equal score",      expected: "TRK-014 → DST-COV-01",  full: "match",   heuristic: "miss",    raw: "miss"    },
  ],
};
