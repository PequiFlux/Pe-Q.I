/* Shared component bits for Pe-Q.I */

const { useState, useEffect, useMemo, useRef, useCallback } = React;

function clsx(...parts) {
  return parts.filter(Boolean).join(" ");
}

/* ── Chips ─────────────────────────────────────────────────────── */
function RuleChip({ id, kind = "pr" }) {
  return <span className="rule-chip" data-kind={kind}>{id}</span>;
}

function HCChip({ id }) {
  const label = (window.HARD_CONSTRAINTS || {})[id] || id;
  return <span className="hc-chip" title={label}>{id}</span>;
}

function OKChip() {
  return <span className="ok-chip">eligible</span>;
}

function Tag({ tone, children }) {
  return (
    <span className="tag" data-tone={tone}>
      <span className="dot" />
      {children}
    </span>
  );
}

function Kbd({ children }) {
  return <span className="kbd">{children}</span>;
}

/* ── Toast ─────────────────────────────────────────────────────── */
function Toast({ msg }) {
  return (
    <div className={clsx("toast", msg && "is-visible")}>
      {msg && <>
        <span className="toast__icon" />
        <span>{msg}</span>
      </>}
    </div>
  );
}

Object.assign(window, { clsx, RuleChip, HCChip, OKChip, Tag, Kbd, Toast });
