/* Pe-Q.I — Root app */

const { useState, useEffect, useMemo, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "density":     "comfortable",
  "runtime":     "text",
  "tone":        "forest"
}/*EDITMODE-END*/;

function App() {
  const [tab, setTab] = useState("workspace");
  const [scenarioId, setScenarioId] = useState("S10_FIFO_BREAK_JUSTIFIED");
  const [runtime, setRuntime] = useState(TWEAK_DEFAULTS.runtime);
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [toast, setToast] = useState(null);
  const [plannerProgress, setPlannerProgress] = useState(5); // 5 = all done
  const [reRunKey, setReRunKey] = useState(0);

  // Sync runtime tweak with toolbar
  useEffect(() => { if (tweaks.runtime !== runtime) setRuntime(tweaks.runtime); }, [tweaks.runtime]);

  // Animate planner when scenario or runtime changes
  useEffect(() => {
    setPlannerProgress(0);
    let step = 0;
    const total = 5;
    const tick = () => {
      step += 1;
      setPlannerProgress(step);
      if (step < total) setTimeout(tick, runtime === "gemma" ? 280 : 120);
    };
    const startDelay = setTimeout(tick, 250);
    return () => clearTimeout(startDelay);
  }, [scenarioId, runtime, reRunKey]);

  // Always use the S10 scenario data, but adapt the label/state to the selected card
  const baseScenario = window.SCENARIO_S10;
  const selectedMeta = window.SCENARIOS.find(s => s.id === scenarioId) || window.SCENARIOS.find(s => s.id === "S10_FIFO_BREAK_JUSTIFIED");
  const scenario = useMemo(() => ({
    ...baseScenario,
    id: selectedMeta.id,
    short: selectedMeta.short,
    name: selectedMeta.name,
    decisionStatus:
      selectedMeta.state === "blocked" ? "BLOCKED" :
      selectedMeta.state === "review" ? "REVIEW_REQUIRED" : "PREVIEW_READY",
  }), [scenarioId]);

  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(window.__toastT);
    window.__toastT = setTimeout(() => setToast(null), 2400);
  }, []);

  const onApprove = (reason) => {
    showToast(`Action recorded · approve · ${reason.slice(0, 56)}${reason.length > 56 ? "…" : ""}`);
  };
  const onBlock = () => showToast("Action recorded · block · sent to operations review");
  const onOverride = (reason) => showToast(`Override recorded · ${reason.slice(0, 56)}`);

  // Keyboard shortcuts
  useEffect(() => {
    function handler(e) {
      if (e.target && /input|textarea/i.test(e.target.tagName)) return;
      const k = e.key.toLowerCase();
      if (k === "1") setTab("workspace");
      else if (k === "2") setTab("audit");
      else if (k === "3") setTab("benchmark");
      else if (k === "a") onApprove("OP-DEMO-01 reviewed the decision.");
      else if (k === "b") onBlock();
      else if (k === "o") onOverride("Override pending reason");
      else if (k === "r") setReRunKey(k => k + 1);
    }
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <div className="app">
      <TopBar tab={tab} setTab={setTab} runtime={runtime} setRuntime={(r) => setTweak("runtime", r)} />
      <Rail
        scenarioId={scenarioId}
        setScenarioId={setScenarioId}
      />
      <main className="main" key={tab}>
        {tab === "workspace" && (
          <Workspace
            scenario={scenario}
            runtime={runtime}
            onApprove={onApprove}
            onBlock={onBlock}
            onOverride={onOverride}
            plannerProgress={plannerProgress}
          />
        )}
        {tab === "audit"     && <Audit scenario={scenario} />}
        {tab === "benchmark" && <Benchmark />}
      </main>
      <Toast msg={toast} />
      <PeqTweaksPanel tweaks={tweaks} setTweak={setTweak} runtime={runtime} setRuntime={(r) => setTweak("runtime", r)} reRun={() => setReRunKey(k => k + 1)} />
    </div>
  );
}

/* ── Top bar ─────────────────────────────────────────────────── */
function TopBar({ tab, setTab, runtime, setRuntime }) {
  const tabs = [
    { id: "workspace", label: "Workspace", kbd: "1" },
    { id: "audit",     label: "Tool audit", kbd: "2" },
    { id: "benchmark", label: "Benchmark",  kbd: "3" },
  ];
  return (
    <header className="topbar">
      <div className="topbar__brand">
        <div className="topbar__brand-mark" />
        <div className="topbar__brand-text">
          Pe-Q.I
          <small>Yard copilot · v1-demo</small>
        </div>
      </div>
      <nav className="topbar__tabs" role="tablist">
        {tabs.map(t => (
          <button
            key={t.id}
            className="topbar__tab"
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
          >
            {t.label}
            <Kbd>{t.kbd}</Kbd>
          </button>
        ))}
      </nav>
      <div className="topbar__right">
        <button className="runtime" data-runtime={runtime} onClick={() => setRuntime(runtime === "text" ? "gemma" : "text")}>
          <span className="dot" />
          {runtime === "text" ? "text runtime" : "gemma 4 · e2b"}
        </button>
        <span className="clock">10:45 UTC · 04 apr 2026</span>
        <span className="op">OP-DEMO-01</span>
      </div>
    </header>
  );
}

/* ── Scenario rail ───────────────────────────────────────────── */
function Rail({ scenarioId, setScenarioId }) {
  const [q, setQ] = useState("");
  const groups = useMemo(() => {
    const g = {};
    window.SCENARIOS
      .filter(s => !q || (s.id + s.name).toLowerCase().includes(q.toLowerCase()))
      .forEach(s => {
        (g[s.category] = g[s.category] || []).push(s);
      });
    return g;
  }, [q]);

  return (
    <aside className="rail">
      <div className="rail__head">
        <h2>Scenarios</h2>
        <span className="count">{window.SCENARIOS.length}</span>
      </div>
      <div className="rail__search">
        <span style={{ color: "var(--ink-400)" }}>⌕</span>
        <input
          placeholder="search S01–S20…"
          value={q}
          onChange={e => setQ(e.target.value)}
        />
        <span className="kbd">/</span>
      </div>
      <div className="rail__list">
        {Object.entries(groups).map(([cat, list]) => (
          <div key={cat}>
            <div className="rail__group">{cat}</div>
            {list.map(s => (
              <div
                key={s.id}
                className="scenario"
                aria-current={scenarioId === s.id ? "true" : "false"}
                onClick={() => setScenarioId(s.id)}
              >
                <div>
                  <div className="scenario__id">{s.short}</div>
                </div>
                <div>
                  <div className="scenario__name">{s.name}</div>
                  <div className="scenario__meta">{s.id.toLowerCase().replace(s.short.toLowerCase() + "_", "")}</div>
                </div>
                <div className="scenario__state" data-state={s.state}>{s.state}</div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </aside>
  );
}

/* ── Tweaks panel ────────────────────────────────────────────── */
function PeqTweaksPanel({ tweaks, setTweak, runtime, setRuntime, reRun }) {
  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Runtime">
        <TweakRadio
          label="Interpretation engine"
          value={runtime}
          options={[
            { value: "text", label: "text" },
            { value: "gemma", label: "gemma 4" },
          ]}
          onChange={(v) => setRuntime(v)}
        />
        <TweakButton label="Re-run decision  ·  R" onClick={reRun} />
      </TweakSection>
      <TweakSection label="Density">
        <TweakRadio
          label="Information density"
          value={tweaks.density}
          options={[
            { value: "comfortable", label: "comfortable" },
            { value: "dense", label: "dense" },
          ]}
          onChange={(v) => {
            setTweak("density", v);
            document.documentElement.style.fontSize = v === "dense" ? "12.5px" : "13.5px";
          }}
        />
      </TweakSection>
      <TweakSection label="Surface tone">
        <TweakRadio
          label="Cream temperature"
          value={tweaks.tone}
          options={[
            { value: "forest", label: "warm cream" },
            { value: "cool",   label: "cool slate" },
          ]}
          onChange={(v) => {
            setTweak("tone", v);
            const root = document.documentElement;
            if (v === "cool") {
              root.style.setProperty("--cream",   "oklch(0.965 0.008 220)");
              root.style.setProperty("--cream-2", "oklch(0.94 0.01 220)");
              root.style.setProperty("--vellum",  "oklch(0.98 0.006 220)");
              root.style.setProperty("--paper",   "oklch(0.995 0.003 220)");
              root.style.setProperty("--hair",    "oklch(0.86 0.01 220)");
            } else {
              root.style.removeProperty("--cream");
              root.style.removeProperty("--cream-2");
              root.style.removeProperty("--vellum");
              root.style.removeProperty("--paper");
              root.style.removeProperty("--hair");
            }
          }}
        />
      </TweakSection>
      <TweakSection label="Keyboard">
        <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: "6px 12px", fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-500)" }}>
          <span>Switch tabs</span><span><kbd>1</kbd> <kbd>2</kbd> <kbd>3</kbd></span>
          <span>Approve · block · override</span><span><kbd>A</kbd> <kbd>B</kbd> <kbd>O</kbd></span>
          <span>Re-run decision</span><span><kbd>R</kbd></span>
          <span>Focus scenario search</span><span><kbd>/</kbd></span>
        </div>
      </TweakSection>
    </TweaksPanel>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
