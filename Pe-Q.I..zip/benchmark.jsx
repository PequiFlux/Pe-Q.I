/* Pe-Q.I — Benchmark tab */

function Benchmark() {
  const b = window.BENCHMARK;

  function fmt(v, suf = "") {
    if (v == null) return "—";
    if (typeof v === "number") {
      if (suf === "%") return (v * 100).toFixed(1) + "%";
      if (Number.isInteger(v)) return v.toString();
      return v.toFixed(3);
    }
    return v;
  }

  return (
    <div className="tab-panel">
      <header style={{ marginBottom: 16 }}>
        <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, letterSpacing: "0.16em", color: "var(--ink-500)", textTransform: "uppercase" }}>
          Benchmark · frozen public snapshot
        </div>
        <h2 style={{ fontFamily: "var(--f-display)", fontStyle: "italic", fontWeight: 400, fontSize: 32, margin: "6px 0 0", letterSpacing: "-0.01em" }}>
          Comparable, reproducible, no production claims.
        </h2>
        <p style={{ margin: "8px 0 0", fontSize: 13, color: "var(--ink-500)", maxWidth: "76ch" }}>
          20 synthetic scenarios × 4 variants = 80 comparative rows. The full variant
          uses Gemma 4 via Ollama; baselines use deterministic rules with no model.
          Zero latencies in this sample are CI fixtures, not real performance.
        </p>
      </header>

      <div className="bench-scope">
        <div className="bench-stat" data-tone="dark">
          <div className="bench-stat__label">Scope</div>
          <div className="bench-stat__value">20<small style={{ fontSize: 16, color: "var(--forest-300)", marginLeft: 4 }}>scenarios</small></div>
          <div className="bench-stat__hint">4 variants · 80 rows · sha-pinned fixtures</div>
        </div>
        <div className="bench-stat">
          <div className="bench-stat__label">Constraint violations · full</div>
          <div className="bench-stat__value">0.00</div>
          <div className="bench-stat__hint">vs 0.35 for raw FIFO</div>
        </div>
        <div className="bench-stat">
          <div className="bench-stat__label">Decision match @1 · full</div>
          <div className="bench-stat__value">1.00</div>
          <div className="bench-stat__hint">+0.15 over heuristic baseline</div>
        </div>
        <div className="bench-stat">
          <div className="bench-stat__label">Audit completeness</div>
          <div className="bench-stat__value">100<small style={{ fontSize: 16, marginLeft: 2 }}>%</small></div>
          <div className="bench-stat__hint">payloads reconstructable end-to-end</div>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden", marginBottom: 14 }}>
        <div className="card__head" style={{ padding: "16px 18px 8px" }}>
          <h3>Variant comparison</h3>
          <span className="meta">same scenarios · same metrics</span>
        </div>
        <table className="variant-table">
          <thead>
            <tr>
              <th>variant</th>
              <th className="num">decision @1</th>
              <th className="num">constraint violations</th>
              <th className="num">exception F1</th>
              <th className="num">ticket field acc.</th>
              <th className="num">audit completeness</th>
              <th className="num">tool success rate</th>
            </tr>
          </thead>
          <tbody>
            {b.variants.map(v => (
              <tr key={v.id} data-best={v.id === "full" ? "true" : "false"}>
                <td>
                  <span className="variant-name">
                    <span className="variant-pill" data-v={v.id}>{v.name}</span>
                    <span style={{ color: "var(--ink-500)", fontSize: 11 }}>
                      {v.gemma ? "with gemma 4" : "deterministic"}
                    </span>
                  </span>
                </td>
                <td className="num"><BenchBar value={v.match} /></td>
                <td className="num">
                  <span style={{ color: v.violations > 0 ? "var(--brick-700)" : "var(--go-700)" }}>{fmt(v.violations)}</span>
                </td>
                <td className="num">{fmt(v.exceptionF1)}</td>
                <td className="num">{fmt(v.ticketAcc)}</td>
                <td className="num">{fmt(v.audit)}</td>
                <td className="num">{v.toolSuccess == null ? "—" : fmt(v.toolSuccess)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="card__head" style={{ padding: "16px 18px 8px" }}>
          <h3>Scenario evidence</h3>
          <span className="meta">selected rows from summary.csv</span>
        </div>
        <div className="scn-list">
          <div className="scn-row" style={{ background: "var(--vellum)", color: "var(--ink-500)", fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase" }}>
            <span>id</span>
            <span>scenario</span>
            <span>expected</span>
            <span>full</span>
            <span>raw fifo</span>
          </div>
          {b.scenarioEvidence.map(s => (
            <div className="scn-row" key={s.id}>
              <span className="scn-row__id">{s.id.split("_")[0]}</span>
              <span className="scn-row__name">{s.name}</span>
              <span className="scn-row__expected">{s.expected}</span>
              <span className="scn-row__metric" data-r="full">
                <span className="scn-row__status" data-s={s.full}>{s.full}</span>
              </span>
              <span className="scn-row__metric" data-r="raw_fifo">
                <span className="scn-row__status" data-s={s.raw}>{s.raw}</span>
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function BenchBar({ value }) {
  if (value == null) return <span>—</span>;
  return (
    <span className="bench-bar">
      <span className="bench-bar__track">
        <span className="bench-bar__fill" style={{ width: `${value * 100}%` }} />
      </span>
      <span>{value.toFixed(2)}</span>
    </span>
  );
}

Object.assign(window, { Benchmark });
