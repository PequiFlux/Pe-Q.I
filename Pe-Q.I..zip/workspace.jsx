/* Pe-Q.I — Workspace tab (operational) */

const { useState: useStateW } = React;

function Workspace({ scenario, runtime, onApprove, onBlock, onOverride, plannerProgress }) {
  const [overrideOpen, setOverrideOpen] = useStateW(false);
  const [reason, setReason] = useStateW("OP-DEMO-01 reviewed the decision.");

  return (
    <div className="tab-panel">
      {/* ── Decision hero ─────────────────────────────────── */}
      <DecisionHero scenario={scenario} />

      {/* ── Action bar ────────────────────────────────────── */}
      <div className="action-bar">
        <div className="action-bar__copy">
          <h3>Awaiting operator authority</h3>
          <p>
            Pe-Q.I has proposed a dispatch. Approve, block, or override —
            override requires a reason and cannot bypass hard constraints (HC-07).
          </p>
        </div>
        <div className="action-bar__btns">
          <button className="btn btn--block" onClick={onBlock}>
            block <Kbd>B</Kbd>
          </button>
          <button className="btn btn--override" onClick={() => setOverrideOpen(o => !o)}>
            override <Kbd>O</Kbd>
          </button>
          <button className="btn btn--approve" onClick={() => onApprove(reason)}>
            approve <Kbd>A</Kbd>
          </button>
        </div>
      </div>

      <div className={clsx("reason-input", overrideOpen && "is-open")}>
        <label>Required reason · audit trail</label>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Why are you overriding the recommendation?"
        />
        <div className="reason-input__row">
          <button className="btn btn--ghost" onClick={() => setOverrideOpen(false)}>cancel</button>
          <button className="btn btn--approve" onClick={() => { onOverride(reason); setOverrideOpen(false); }}>
            register override
          </button>
        </div>
      </div>

      {/* ── 3-col main grid ──────────────────────────────── */}
      <div className="workgrid">
        <QueueCard scenario={scenario} />
        <MatrixCard scenario={scenario} />
        <ContextCol scenario={scenario} runtime={runtime} />
      </div>

      {/* ── Planner strip ────────────────────────────────── */}
      <PlannerStrip scenario={scenario} progress={plannerProgress} runtime={runtime} />
    </div>
  );
}

/* ── Decision hero ───────────────────────────────────────────── */
function DecisionHero({ scenario }) {
  return (
    <section className="hero">
      <div className="hero__call">
        <div className="hero__eyebrow">
          <span className="pulse" />
          <span>Decision · {scenario.requestId}</span>
          <span style={{ color: "var(--forest-200)" }}>·</span>
          <span>{scenario.decisionStatus.toLowerCase().replace("_", " ")}</span>
        </div>
        <h1>
          Call <span className="id">{scenario.recommendedTruck}</span>
          <span className="arrow">→</span>
          <span className="id">{scenario.recommendedDestination}</span>
        </h1>
        <p className="hero__reason">{scenario.reasonSummary}</p>
        <div className="hero__rules">
          {scenario.hardConstraints.map(c => <RuleChip key={c} id={c} kind="hc" />)}
          {scenario.firedRules.map(c => <RuleChip key={c} id={c} kind="pr" />)}
          <span className="rule-chip" style={{ borderColor: "var(--forest-700)", color: "var(--forest-200)" }}>
            policy v1-demo
          </span>
        </div>
      </div>
      <div className="hero__stats">
        <div className="stat" data-tone="go">
          <div className="stat__label">Status</div>
          <div className="stat__value" style={{ fontFamily: "var(--f-display)", fontStyle: "italic", fontSize: "26px" }}>
            preview ready
          </div>
          <div className="stat__hint">awaiting operator</div>
        </div>
        <div className="stat">
          <div className="stat__label">Rejected pairs</div>
          <div className="stat__value">{scenario.rejected}<small>/ 20</small></div>
          <div className="stat__hint">filtered by hard constraints</div>
        </div>
        <div className="stat">
          <div className="stat__label">Decision latency</div>
          <div className="stat__value">{scenario.latencyMs}<small>ms</small></div>
          <div className="stat__hint">local pipeline · text runtime</div>
        </div>
        <div className="stat" data-tone="amber">
          <div className="stat__label">Wait pressure</div>
          <div className="stat__value">2<small>h 29m</small></div>
          <div className="stat__hint">PR-04 fired</div>
        </div>
      </div>
    </section>
  );
}

/* ── Queue ───────────────────────────────────────────────────── */
function QueueCard({ scenario }) {
  return (
    <div className="card">
      <div className="card__head">
        <h3>Decision queue</h3>
        <span className="meta">5 of {scenario.queue.length} · {scenario.queue.filter(t => t.status === "called").length} called</span>
      </div>
      <p className="card__subtle">First five trucks as the operator sees them — promoted, waiting, and the constraint behind each state.</p>
      <div className="queue">
        {scenario.queue.map(t => (
          <div key={t.id} className="queue__row" data-status={t.status}>
            <div className="queue__pos">#{t.pos}</div>
            <div className="queue__main">
              <div className="queue__id">
                {t.id}
                {t.status === "called" && <span className="called-pill">called now</span>}
              </div>
              <div className="queue__sub">
                {t.vehicle}<span className="arrow">→</span>{t.destDeclared}<span className="arrow">·</span>{t.waitMin}m wait
              </div>
            </div>
            <div className="queue__reason">
              {t.blocked.length === 0
                ? <OKChip />
                : t.blocked.map(c => <HCChip key={c} id={c} />)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Constraint matrix ───────────────────────────────────────── */
function MatrixCard({ scenario }) {
  const trucks = scenario.queue;
  const dsts = window.DESTINATIONS;
  const rec = { t: scenario.recommendedTruck, d: scenario.recommendedDestination };

  // Mock per-cell constraint resolution
  function cellState(truck, dst) {
    if (truck.id === rec.t && dst.id === rec.d) return { c: "called", label: "CALL" };
    // HC-01: rain + open dst
    if (dst.exposure === "open") return { c: "hc", label: "HC-01" };
    // HC-05: vehicle compatibility
    if (!dst.vehicles.includes(truck.vehicle)) return { c: "hc", label: "HC-05" };
    return { c: "ok", label: "ok" };
  }

  return (
    <div className="card">
      <div className="card__head">
        <h3>Constraint matrix</h3>
        <span className="meta">5 × 4 · {scenario.rejected} rejected</span>
      </div>
      <p className="card__subtle">Every truck × every destination, with the hard constraint that eliminated each pair.</p>
      <table className="matrix">
        <thead>
          <tr>
            <th style={{ minWidth: 84 }}>truck \ dst</th>
            {dsts.map(d => (
              <th key={d.id} className="dst" title={`${d.type} · ${d.exposure}`}>
                {d.id.replace("DST-", "")}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {trucks.map(t => (
            <tr key={t.id}>
              <th>
                {t.id}<span className="vtype">· {t.vehicle}</span>
              </th>
              {dsts.map(d => {
                const c = cellState(t, d);
                return (
                  <td key={d.id}>
                    <div className="cell" data-c={c.c} title={c.c === "hc" ? window.HARD_CONSTRAINTS[c.label] : c.label}>
                      {c.label}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="matrix__legend">
        <span><span className="swatch" style={{ background: "var(--forest-950)" }} /> called</span>
        <span><span className="swatch" style={{ background: "var(--go-100)" }} /> eligible</span>
        <span><span className="swatch" style={{ background: "var(--brick-50)" }} /> hard-constraint hit</span>
      </div>
    </div>
  );
}

/* ── Context column ──────────────────────────────────────────── */
function ContextCol({ scenario, runtime }) {
  const t = scenario.ticket;
  return (
    <div className="ctx">
      {/* Document interpretation */}
      <div className="card">
        <div className="card__head">
          <h3>Document interpretation</h3>
          <span className="meta">{runtime === "gemma" ? "gemma 4 · e2b" : "text runtime"}</span>
        </div>
        <p className="card__subtle">Ticket fields used in the decision — interpreted, hashed, attributed in the audit payload.</p>
        <div className="kv-grid">
          <div className="kv">
            <span className="kv__k">Ticket</span>
            <span className="kv__v">{t.id}</span>
          </div>
          <div className="kv">
            <span className="kv__k">Read truck</span>
            <span className="kv__v">{t.truckId}</span>
          </div>
          <div className="kv">
            <span className="kv__k">Vehicle</span>
            <span className="kv__v">{t.vehicleType}</span>
          </div>
          <div className="kv">
            <span className="kv__k">Load</span>
            <span className="kv__v">{t.loadCondition}</span>
          </div>
          <div className="kv">
            <span className="kv__k">Doc status</span>
            <span className="kv__v">{t.documentStatus}</span>
          </div>
          <div className="kv">
            <span className="kv__k">Contract</span>
            <span className="kv__v">{t.contractPriority ? "priority" : "—"}</span>
          </div>
        </div>
        <div style={{ marginTop: 12 }}>
          <div className="kv__k" style={{ marginBottom: 6 }}>Parse confidence</div>
          <div className="confidence">
            <div className="confidence__bar"><i style={{ width: `${t.parseConfidence * 100}%` }} /></div>
            <span>{(t.parseConfidence * 100).toFixed(0)}%</span>
          </div>
        </div>
      </div>

      {/* Conditions */}
      <div className="card">
        <div className="card__head">
          <h3>Yard conditions</h3>
          <span className="meta">live state</span>
        </div>
        <div className="compact-row">
          <span className="compact-row__k">Weather</span>
          <span className="compact-row__v">
            <Tag tone="rain">rain · high</Tag>
          </span>
        </div>
        {scenario.resources.map(r => (
          <div className="compact-row" key={r.id}>
            <span className="compact-row__k">{r.id}</span>
            <span className="compact-row__v">
              {r.status === "blocked"
                ? <Tag tone="open">blocked · {r.blockedBy}</Tag>
                : <Tag tone="avail">{r.capacity}% capacity</Tag>}
            </span>
          </div>
        ))}
      </div>

      {/* Operator note */}
      <div className="card">
        <div className="card__head">
          <h3>Operator note</h3>
          <span className="meta">pt-br</span>
        </div>
        <p style={{ margin: "0 0 8px", fontSize: 13, color: "var(--ink-700)" }}>
          "{scenario.operatorNote}"
        </p>
        <p style={{ margin: 0, fontSize: 11.5, color: "var(--ink-500)", fontStyle: "italic" }}>
          {scenario.operatorNoteEn}
        </p>
      </div>

      {/* Driver message */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="card__head" style={{ padding: "16px 16px 0" }}>
          <h3>Driver message</h3>
          <span className="meta">220 char max</span>
        </div>
        <div style={{ padding: "0 16px 16px" }}>
          <p className="card__subtle">Plain-language outgoing instruction. The operator can edit before send.</p>
          <div className="phone">
            <div className="phone__screen">
              <div className="phone__header">
                <span>PequiFlux · driver app</span>
                <span>now</span>
              </div>
              <div className="phone__msg">
                Call <b>{scenario.recommendedTruck}</b> to <b>{scenario.recommendedDestination}</b>.
                FIFO break justified by long wait time and rain on open hoppers. Approach covered hopper bay 01.
              </div>
              <div className="phone__meta">
                <span>delivered</span>
                <span>{scenario.driverMessage.length} / 220</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Planner strip ───────────────────────────────────────────── */
function PlannerStrip({ scenario, progress, runtime }) {
  return (
    <section className="planner">
      <div className="planner__head">
        <h3>Gemma tool planner trace</h3>
        <span className="meta">
          {runtime === "gemma" ? "gemma-tool-planner · 5/5 steps · 743 ms" : "text runtime · deterministic intent"}
        </span>
      </div>
      <div className="steps">
        {scenario.planner.map((p, i) => {
          const state = i < progress ? "done" : i === progress ? "active" : "queued";
          return (
            <div className="step" key={p.step} data-state={state}>
              <span className="step__dot" />
              <span className="step__name">{p.tool}</span>
              <span className="step__detail">{p.intent} · → {p.state}</span>
              <span className="step__latency">
                {state === "queued" ? "—" :
                 state === "active" ? "…running" :
                 `${scenario.tools[i]?.latency ?? 0} ms`}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
}

Object.assign(window, { Workspace });
